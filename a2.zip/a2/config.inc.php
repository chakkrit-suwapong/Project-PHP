<?
$host="localhost";
$user="root";
$pw="jaksiam";
$dbname="a2";
$c = mysql_connect($host,$user,$pw);
if (!$c) {
	echo "<H3>COMPUTER GROUP</H3>";
	exit();
}
?>