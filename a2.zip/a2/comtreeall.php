<font size = '2'
  >
<?php		// menutree.php (Mysql)
require("config.inc.php");



mysql_connect($host, $user, $pw) or  die("�������Ͱҹ�����������");
mysql_query("set NAMES utf8   ");
mysql_select_db($dbname) or die("���͡�ҹ�����������"); // ���͡�ҹ������




//////////////////////////////////// CPU SELECT///////////////////////////////////////////














//////////////////////////////////////////////////////////////////////////////////////////////
$sql = "SELECT *  from kind where kindname='CPU'  ";  // cat_label
$result = mysql_query( $sql); 

	
		echo"  SELECT CPU SPEED FOR $allbandname   <BR>";  
		
			
While( $fetcharr = mysql_fetch_array($result) )
 { 
	    
			
			                                      	$val1= $fetcharr['kindid'];
												
													
													$label1 = $fetcharr['kindname'];
													$labelpic1 = $fetcharr['kindpic'];
													
														
														
														
	                          echo "<img src=bullet4.jpg> <a href=comtreeall.php?cat1=$val1><left>$label1 </a><br>" ;





////////////////////////////////////////////////////////////////////////////////////////

if($cat1==$val1){

///if($cat55555==$allbandid){

//////////////FOR SEO if($cat1==$val1){

$sql = "SELECT *  from allband where allbandname='INTEL' or allbandname='AMD' ";  // cat_label
$result = mysql_query( $sql); 

	echo"  SELECT CPU BAND NAME   <BR>";  
While( $fetcharr = mysql_fetch_array($result) )
 { 
	    
			
			                                      	$allbandid= $fetcharr['allbandid'];
												
													
													$allbandname = $fetcharr['allbandname'];
													
														
														
														
	                          echo "<img src=bullet4.jpg> <a href=comtreeall.php?cat1=$val1&cat55555=$allbandid><left>$allbandname </a><br>" ;


///////////////////////////////////////////////////////////////////////yesssssssssssssssssssssssssssss//////////////////////////////////////////////////////////////////////////////

if($cat55555==$allbandid){

////if($cat1==$val1){

//////////////FOR SEO if($cat1==$val1){

$sql = "SELECT *  from selectnext  ";  // cat_label
$result = mysql_query( $sql); 

	echo"  SELECT CPU BAND NAME   <BR>";  
While( $fetcharr = mysql_fetch_array($result) )
 { 
	    
			
			                                      	$selectnextid= $fetcharr['selectnextid'];
												
													
													$selectnextname = $fetcharr['selectnextname'];
													
														
														
														
	                          echo "<img src=bullet4.jpg> <a href=comtreeall.php?cat1=$val1&cat55555=$allbandid&catselectnext=$selectnextid><left>$selectnextname </a><br>" ;





////////////////////////////////////////////////////////////////////////////yessssssssssssssssssssssssssssssssssssssssssssss////////////////////////////////////////////////////////////////////////////


if($catselectnext==$selectnextid){


///if($cat55555==$allbandid){



//////////////FOR SEO if($cat1==$val1){




$sql = "SELECT  * from allproduct  where refkind='$cat1'&&refallband='$cat55555'  ";  // cat_label
$result = mysql_query( $sql); 

  echo"  SELECT CPU SPEED   <BR>"; 
   
			
While( $fetcharr = mysql_fetch_array($result) )
 { 
	    
			
			                                      	$val2= $fetcharr['allproductid'];
									
													$label2 = $fetcharr['refkind'];
													$label3 = $fetcharr['refallband'];
													$label4 = $fetcharr['refallspecial'];
													$label5 = $fetcharr['statusvga'];
													$label6 = $fetcharr['reframselect'];
													$label7 = $fetcharr['vgaslot'];
													$label8 = $fetcharr['alldetail'];
													$label9 = $fetcharr['allprice'];
													$labelpic9 = $fetcharr['allpic'];

													
														
														
														
	                          echo "<img src=bullet4.jpg> <a href=comtreeall.php?cat55555=$allbandid&cat1=$val1&cat2=$val2&catcpu=$label4><left>$label8 </a><br>" ;


//////////////////////////////////// MOTHER BOARD SELECT///////////////////////////////////////////



if($cat2==$val2){
//////////////FOR SEO if($cat1==$val1){



$sql = "SELECT *  from kind where kindname='MOTHER BOARD'  ";  // cat_label
$result = mysql_query( $sql); 
 echo" SELECT MOTHER BOARD  <BR>"; 
   
			
While( $fetcharr = mysql_fetch_array($result) )
 { 
	    
			
			                                      	$val3= $fetcharr['kindid'];
												
													
													$label11 = $fetcharr['kindname'];
													
																		
	                          echo "<img src=bullet4.jpg> <a href=comtreeall.php?cat55555=$allbandid&cat1=$val1&cat2=$val2&catcpu=$label4&cat3=$val3><left>$label11 </a><br>" ;


if($cat3==$val3){

//////////////FOR SEO if($cat1==$val1){

$sql = "SELECT *  from allspecial where allspecialname='VGA ON BOARD' OR  allspecialname='NO VGA ON BOARD' ";  // cat_label
$result = mysql_query( $sql);
   echo" SPECIAL OPTION FOR MOTHER BOARD   <BR>"; 
			
While( $fetcharr = mysql_fetch_array($result) )
 { 
	    
			
			                                      	$val4= $fetcharr['allspecialid'];
												
													
													$label12 = $fetcharr['allspecialname'];
													
														
														
														
	                        echo "<img src=bullet4.jpg> <a href=comtreeall.php?cat55555=$allbandid&cat1=$val1&cat2=$val2&catcpu=$label4&cat3=$val3&cat4=$val4><left>$label12 </a><br>" ;









if($cat4==$val4){

//////////////FOR SEO if($cat1==$val1){


$sql = "SELECT  * from allproduct  where refkind='$cat3'&&statusvga='$cat4'&&refallspecial='$catcpu'  ";  // cat_label
$result = mysql_query( $sql); 

  echo"  SELECT MOTHER BOARD   <BR>"; 
   
			
While( $fetcharr = mysql_fetch_array($result) )
 { 
	    
			
			                                      	$val5= $fetcharr['allproductid'];
									
													$label21 = $fetcharr['refkind'];
													$label22 = $fetcharr['refallband'];
													$label23 = $fetcharr['refallspecial'];
													$label24 = $fetcharr['statusvga'];
													$label25 = $fetcharr['reframselect'];
													$label26 = $fetcharr['vgaslot'];
													$label27 = $fetcharr['alldetail'];
													$label28 = $fetcharr['allprice'];
													$labelpic28 = $fetcharr['allpic'];

													
														
														
						   echo "<img src=bullet4.jpg> <a href=comtreeall.php?cat55555=$allbandid&cat1=$val1&cat2=$val2&catcpu=$label4&cat3=$val3&cat4=$val4&cat5=$val5&cat7777=$label25
						  ><left>$label27</a><br>" ;







if($cat5==$val5){

//////////////FOR SEO if($cat1==$val1){
$sql = "SELECT *  from kind where kindname='RAM'  ";  // cat_label
$result = mysql_query( $sql); 
 echo" SELECT MEMORY  <BR>"; 
   
			
While( $fetcharr = mysql_fetch_array($result) )
 { 
	    
			
			                                      	$val6= $fetcharr['kindid'];
												
													
													$label29 = $fetcharr['kindname'];
													
						




								
						   echo "<img src=bullet4.jpg> <a href=comtreeall.php?cat55555=$allbandid&cat1=$val1&cat2=$val2&catcpu=$label4&cat3=$val3&cat4=$val4&cat5=$val5&cat6=$val6&cat7777=$label25
						   
						   ><left>$label29</a><br>" ;












if($cat6==$val6){
//////////////FOR SEO if($cat1==$val1){


$sql = "SELECT  * from allproduct  where refkind='$cat6'&&refallspecial='$cat7777'  ";  // cat_label
$result = mysql_query( $sql); 

  echo"  SELECT RAM SPECT   <BR>"; 
   
			
While( $fetcharr = mysql_fetch_array($result) )
 { 
	    
			
			                                      	$val7= $fetcharr['allproductid'];
									
													$label29 = $fetcharr['refkind'];
													$label31 = $fetcharr['refallband'];
													$label32 = $fetcharr['refallspecial'];
													$label33 = $fetcharr['statusvga'];
													$label34 = $fetcharr['reframselect'];
													$label35 = $fetcharr['vgaslot'];
													$label36 = $fetcharr['alldetail'];
													$label37 = $fetcharr['allprice'];
													$labelpic37 = $fetcharr['allpic'];

						
						

							
						   echo "<img src=bullet4.jpg> <a href=comtreeall.php?cat55555=$allbandid&cat1=$val1&cat2=$val2&catcpu=$label4&cat3=$val3&cat4=$val4&cat5=$val5&cat6=$val6&cat7777=$label25&cat7=$val7><left>$label36</a><br>" ;
						   
						

/////////////////////////////////GRAPHIC CARD/////////////////////////////////////////////////////

if($cat7==$val7){

//////////////FOR SEO if($cat1==$val1){
$sql = "SELECT *  from kind where kindname='GRAPHIC CARD'  ";  // cat_label
$result = mysql_query( $sql); 
 echo" SELECT GRAPHIC CARD  <BR>"; 
   
			
While( $fetcharr = mysql_fetch_array($result) )
 { 
	    
			
			                                      	$val8= $fetcharr['kindid'];
												
													
													$label38 = $fetcharr['kindname'];
													
						




								
						   echo "<img src=bullet4.jpg> <a href=comtreeall.php?cat55555=$allbandid&cat1=$val1&cat2=$val2&catcpu=$label4&cat3=$val3&cat4=$val4&cat5=$val5&cat6=$val6&cat7777=$label25&cat7=$val7&cat8=$val8
						   
						   ><left>$label38</a><br>" ;







if($cat8==$val8){

//////////////FOR SEO if($cat1==$val1){


$sql = "SELECT  * from allproduct  where refkind='$cat8'&&vgaslot='$label26'  ";  // cat_label
$result = mysql_query( $sql); 

  echo"  SELECT GRAPHIC CARD SPECT   <BR>"; 
   
			
While( $fetcharr = mysql_fetch_array($result) )
 { 
	    
			
			                                      	$val9= $fetcharr['allproductid'];
									
													$label39 = $fetcharr['refkind'];
													$label41 = $fetcharr['refallband'];
													$label42 = $fetcharr['refallspecial'];
													$label43 = $fetcharr['statusvga'];
													$label44 = $fetcharr['reframselect'];
													$label45 = $fetcharr['vgaslot'];
													$label46 = $fetcharr['alldetail'];
													$label47 = $fetcharr['allprice'];
													$labelpic47 = $fetcharr['allpic'];

						
						

							
						   echo "<img src=bullet4.jpg> <a href=comtreeall.php?cat55555=$allbandid&cat1=$val1&cat2=$val2&catcpu=$label4&cat3=$val3&cat4=$val4&cat5=$val5&cat6=$val6&cat7777=$label25&cat7=$val7&cat8=$val8&cat9=$val9><left>$label46</a><br>" ;
						   
						
////////////////////////////////////////////////HARD/////////////////////////////////////

if($cat9==$val9){


//////////////FOR SEO if($cat1==$val1){
$sql = "SELECT *  from kind where kindname='HARD DISK'  ";  // cat_label
$result = mysql_query( $sql); 
 echo" SELECT HARD DISK  <BR>"; 
   
			
While( $fetcharr = mysql_fetch_array($result) )
 { 
	    
			
			                                      	$val11= $fetcharr['kindid'];
												
													
													$label48 = $fetcharr['kindname'];
													
						




				   echo "<img src=bullet4.jpg> <a href=comtreeall.php?cat55555=$allbandid&cat1=$val1&cat2=$val2&catcpu=$label4&cat3=$val3&cat4=$val4&cat5=$val5&cat6=$val6&cat7777=$label25&cat7=$val7&cat8=$val8&cat9=$val9&cat11=$val11><left>$label48</a><br>" ;
						   










if($cat11==$val11){

//////////////FOR SEO if($cat1==$val1){


$sql = "SELECT  * from allproduct  where refkind='$cat11'  ";  // cat_label
$result = mysql_query( $sql); 

  echo"  SELECT HARD DISK SPECT   <BR>"; 
   
			
While( $fetcharr = mysql_fetch_array($result) )
 { 
	    
			
			                                      	$val12= $fetcharr['allproductid'];
									
													$label49 = $fetcharr['refkind'];
													$label51 = $fetcharr['refallband'];
													$label52 = $fetcharr['refallspecial'];
													$label53 = $fetcharr['statusvga'];
													$label54 = $fetcharr['reframselect'];
													$label55 = $fetcharr['vgaslot'];
													$label56 = $fetcharr['alldetail'];
													$label57 = $fetcharr['allprice'];
													$labelpic57 = $fetcharr['allpic'];

						
						

   echo "<img src=bullet4.jpg> <a href=comtreeall.php?cat55555=$allbandid&cat1=$val1&cat2=$val2&catcpu=$label4&cat3=$val3&cat4=$val4&cat5=$val5&cat6=$val6&cat7777=$label25&cat7=$val7&cat8=$val8&cat9=$val9&cat11=$val11&cat12=$val12><left>$label56</a><br>" ;
						   
///////////////////////////////////////////CD ROM/////////////////////////////
if($cat12==$val12){

//////////////FOR SEO if($cat1==$val1){
$sql = "SELECT *  from kind where kindname='CD' or kindname='DVD'  ";  // cat_label
$result = mysql_query( $sql); 
 echo" SELECT CD ROM  <BR>"; 
   
			
While( $fetcharr = mysql_fetch_array($result) )
 { 
	    
			
			                                      	$val13= $fetcharr['kindid'];
												
													
													$label58 = $fetcharr['kindname'];
													
						



						
 echo "<img src=bullet4.jpg> <a href=comtreeall.php?cat55555=$allbandid&cat1=$val1&cat2=$val2&catcpu=$label4&cat3=$val3&cat4=$val4&cat5=$val5&cat6=$val6&cat7777=$label25&cat7=$val7&cat8=$val8&cat9=$val9&cat11=$val11&cat12=$val12&cat13=$val13><left>$label58</a><br>" ;







if($cat13==$val13){

//////////////FOR SEO if($cat1==$val1){


$sql = "SELECT  * from allproduct  where refkind='$cat13'  ";  // cat_label
$result = mysql_query( $sql); 

  echo"  SELECT CD ROM SPECT  <BR>"; 
   
			
While( $fetcharr = mysql_fetch_array($result) )
 { 
	    
			
			                                      	$val14= $fetcharr['allproductid'];
									
													$label59 = $fetcharr['refkind'];
													$label61 = $fetcharr['refallband'];
													$label62 = $fetcharr['refallspecial'];
													$label63 = $fetcharr['statusvga'];
													$label64 = $fetcharr['reframselect'];
													$label65 = $fetcharr['vgaslot'];
													$label66 = $fetcharr['alldetail'];
													$label67 = $fetcharr['allprice'];
													$labelpic67 = $fetcharr['allpic'];

						
						 echo "<img src=bullet4.jpg> <a href=comtreeall.php?cat55555=$allbandid&cat1=$val1&cat2=$val2&catcpu=$label4&cat3=$val3&cat4=$val4&cat5=$val5&cat6=$val6&cat7777=$label25&cat7=$val7&cat8=$val8&cat9=$val9&cat11=$val11&cat12=$val12&cat13=$val13&cat14=$val14><left>$label66</a><br>" ;






///////////////////////////////////////////DVD ROM/////////////////////////////

//////////////////////////////////////////FROPY DISK//////////////////////////
if($cat14==$val14){

//////////////FOR SEO if($cat1==$val1){
$sql = "SELECT *  from kind where kindname='FROPY DISK'  ";  // cat_label
$result = mysql_query( $sql); 
 echo" SELECT FROPY DISK  <BR>"; 
   
			
While( $fetcharr = mysql_fetch_array($result) )
 { 
	    
			
			                                      	$val17= $fetcharr['kindid'];
												
													
													$label78 = $fetcharr['kindname'];
													
						




 echo "<img src=bullet4.jpg> <a href=comtreeall.php?cat55555=$allbandid&cat1=$val1&cat2=$val2&catcpu=$label4&cat3=$val3&cat4=$val4&cat5=$val5&cat6=$val6&cat7777=$label25&cat7=$val7&cat8=$val8&cat9=$val9&cat11=$val11&cat12=$val12&cat13=$val13&cat14=$val14&cat17=$val17><left>$label78</a><br>" ;







if($cat17==$val17){
//////////////FOR SEO if($cat1==$val1){

$sql = "SELECT  * from allproduct  where refkind='$cat17' ";  // cat_label
$result = mysql_query( $sql); 

  echo"  SELECT FROPY DISK SPECT   <BR>"; 
   
			
While( $fetcharr = mysql_fetch_array($result) )
 { 
	    
			
			                                      	$val18= $fetcharr['allproductid'];
									
													$label79 = $fetcharr['refkind'];
													$label81 = $fetcharr['refallband'];
													$label82 = $fetcharr['refallspecial'];
													$label83 = $fetcharr['statusvga'];
													$label84 = $fetcharr['reframselect'];
													$label85 = $fetcharr['vgaslot'];
													$label86 = $fetcharr['alldetail'];
													$label87 = $fetcharr['allprice'];
													$labelpic87 = $fetcharr['allpic'];

						
						




 echo "<img src=bullet4.jpg> <a href=comtreeall.php?cat55555=$allbandid&cat1=$val1&cat2=$val2&catcpu=$label4&cat3=$val3&cat4=$val4&cat5=$val5&cat6=$val6&cat7777=$label25&cat7=$val7&cat8=$val8&cat9=$val9&cat11=$val11&cat12=$val12&cat13=$val13&cat14=$val14&cat17=$val17&cat18=$val18><left>$label86</a><br>" ;






////////////////////////////////////////////////////////////////////////////

/////////////////////////////////CASE/////////////////////////////////////////////////////



if($cat18==$val18){

//////////////FOR SEO if($cat1==$val1){
$sql = "SELECT *  from kind where kindname='CASE'  ";  // cat_label
$result = mysql_query( $sql); 
 echo" SELECT CASE  <BR>"; 
   
			
While( $fetcharr = mysql_fetch_array($result) )
 { 
	    
			
			                                      	$val19= $fetcharr['kindid'];
												
													
													$label88 = $fetcharr['kindname'];
													
						


echo "<img src=bullet4.jpg> <a href=comtreeall.php?cat55555=$allbandid&cat1=$val1&cat2=$val2&catcpu=$label4&cat3=$val3&cat4=$val4&cat5=$val5&cat6=$val6&cat7777=$label25&cat7=$val7&cat8=$val8&cat9=$val9&cat11=$val11&cat12=$val12&cat13=$val13&cat14=$val14&cat17=$val17&cat18=$val18&cat19=$val19><left>$label88</a><br>" ;






if($cat19==$val19){

//////////////FOR SEO if($cat1==$val1){
$sql = "SELECT  * from allproduct  where refkind='$cat19'  ";  // cat_label
$result = mysql_query( $sql); 

  echo"  SELECT CASE SPECT   <BR>"; 
   
			
While( $fetcharr = mysql_fetch_array($result) )
 { 
	    
			
			                                      	$val21= $fetcharr['allproductid'];
									
													$label89 = $fetcharr['refkind'];
													$label71 = $fetcharr['refallband'];
													$label72 = $fetcharr['refallspecial'];
													$label73 = $fetcharr['statusvga'];
													$label74 = $fetcharr['reframselect'];
													$label75 = $fetcharr['vgaslot'];
													$label76 = $fetcharr['alldetail'];
													$label77 = $fetcharr['allprice'];
													$labelpic77 = $fetcharr['allpic'];

						
				echo "<img src=bullet4.jpg> <a href=comtreeall.php?cat55555=$allbandid&cat1=$val1&cat2=$val2&catcpu=$label4&cat3=$val3&cat4=$val4&cat5=$val5&cat6=$val6&cat7777=$label25&cat7=$val7&cat8=$val8&cat9=$val9&cat11=$val11&cat12=$val12&cat13=$val13&cat14=$val14&cat17=$val17&cat18=$val18&cat19=$val19&cat21=$val21><left>$label76</a><br>" ;




/////////////////////////////////POWER SUPPLY/////////////////////////////////////////////////////






if($cat21==$val21){

//////////////FOR SEO if($cat1==$val1){
$sql = "SELECT *  from kind where kindname='POWER SUPPLY'  ";  // cat_label
$result = mysql_query( $sql); 
 echo" SELECT POWER SUPPLY  <BR>"; 
   
			
While( $fetcharr = mysql_fetch_array($result) )
 { 
	    
			
			                                      	$val22= $fetcharr['kindid'];
												
													
													$label78 = $fetcharr['kindname'];
													
						
			
				echo "<img src=bullet4.jpg> <a href=comtreeall.php?cat55555=$allbandid&cat1=$val1&cat2=$val2&catcpu=$label4&cat3=$val3&cat4=$val4&cat5=$val5&cat6=$val6&cat7777=$label25&cat7=$val7&cat8=$val8&cat9=$val9&cat11=$val11&cat12=$val12&cat13=$val13&cat14=$val14&cat17=$val17&cat18=$val18&cat19=$val19&cat21=$val21&cat22=$val22><left>$label78</a><br>" ;



if($cat22==$val22){
//////////////FOR SEO if($cat1==$val1){

$sql = "SELECT  * from allproduct  where refkind='$cat22'  ";  // cat_label
$result = mysql_query( $sql); 

  echo"  SELECT  POWER SUPPLY SPECT   <BR>"; 
   
			
While( $fetcharr = mysql_fetch_array($result) )
 { 
	    
			
			                                      	$val23= $fetcharr['allproductid'];
									
													$label79 = $fetcharr['refkind'];
													$label81 = $fetcharr['refallband'];
													$label82 = $fetcharr['refallspecial'];
													$label83 = $fetcharr['statusvga'];
													$label84 = $fetcharr['reframselect'];
													$label85 = $fetcharr['vgaslot'];
													$label86 = $fetcharr['alldetail'];
													$label87 = $fetcharr['allprice'];
													$labelpic87 = $fetcharr['allpic'];

									
				echo "<img src=bullet4.jpg> <a href=comtreeall.php?cat55555=$allbandid&cat1=$val1&cat2=$val2&catcpu=$label4&cat3=$val3&cat4=$val4&cat5=$val5&cat6=$val6&cat7777=$label25&cat7=$val7&cat8=$val8&cat9=$val9&cat11=$val11&cat12=$val12&cat13=$val13&cat14=$val14&cat17=$val17&cat18=$val18&cat19=$val19&cat21=$val21&cat22=$val22&cat23=$val23><left>$label86</a><br>" ;

					


/////////////////////////////////MONITOR/////////////////////////////////////////////////////




if($cat23==$val23){


//////////////FOR SEO if($cat1==$val1){
$sql = "SELECT *  from kind where kindname='MONITOR'  ";  // cat_label
$result = mysql_query( $sql); 
 echo" SELECT MONITOR  <BR>"; 
   
			
While( $fetcharr = mysql_fetch_array($result) )
 { 
	    
			
			                                      	$val24= $fetcharr['kindid'];
												
													
													$label88 = $fetcharr['kindname'];
													
						

			
				echo "<img src=bullet4.jpg> <a href=comtreeall.php?cat55555=$allbandid&cat1=$val1&cat2=$val2&catcpu=$label4&cat3=$val3&cat4=$val4&cat5=$val5&cat6=$val6&cat7777=$label25&cat7=$val7&cat8=$val8&cat9=$val9&cat11=$val11&cat12=$val12&cat13=$val13&cat14=$val14&cat17=$val17&cat18=$val18&cat19=$val19&cat21=$val21&cat22=$val22&cat23=$val23&cat24=$val24><left>$label88</a><br>" ;







if($cat24==$val24){

//////////////FOR SEO if($cat1==$val1){
$sql = "SELECT  * from allproduct  where refkind='$cat24'  ";  // cat_label
$result = mysql_query( $sql); 

  echo"  SELECT MONITOR SPECT   <BR>"; 
   
			
While( $fetcharr = mysql_fetch_array($result) )
 { 
	    
			
			                                      	$val25= $fetcharr['allproductid'];
									
													$label89 = $fetcharr['refkind'];
													$label91 = $fetcharr['refallband'];
													$label92 = $fetcharr['refallspecial'];
													$label93 = $fetcharr['statusvga'];
													$label94 = $fetcharr['reframselect'];
													$label95 = $fetcharr['vgaslot'];
													$label96 = $fetcharr['alldetail'];
													$label97 = $fetcharr['allprice'];
													$labelpic97 = $fetcharr['allpic'];

								
				echo "<img src=bullet4.jpg> <a href=comtreeall.php?cat55555=$allbandid&cat1=$val1&cat2=$val2&catcpu=$label4&cat3=$val3&cat4=$val4&cat5=$val5&cat6=$val6&cat7777=$label25&cat7=$val7&cat8=$val8&cat9=$val9&cat11=$val11&cat12=$val12&cat13=$val13&cat14=$val14&cat17=$val17&cat18=$val18&cat19=$val19&cat21=$val21&cat22=$val22&cat23=$val23&cat24=$val24&cat25=$val25><left>$label96</a><br>" ;
	
						

/////////////////////////////////MOUSE/////////////////////////////////////////////////////


if($cat25==$val25){


//////////////FOR SEO if($cat1==$val1){
$sql = "SELECT *  from kind where kindname='MOUSE'  ";  // cat_label
$result = mysql_query( $sql); 
 echo" SELECT MOUSE  <BR>"; 
   
			
While( $fetcharr = mysql_fetch_array($result) )
 { 
	    
			
			                                      	$val26= $fetcharr['kindid'];
												
													
													$label98 = $fetcharr['kindname'];
													
						

			
				echo "<img src=bullet4.jpg> <a href=comtreeall.php?cat55555=$allbandid&cat1=$val1&cat2=$val2&catcpu=$label4&cat3=$val3&cat4=$val4&cat5=$val5&cat6=$val6&cat7777=$label25&cat7=$val7&cat8=$val8&cat9=$val9&cat11=$val11&cat12=$val12&cat13=$val13&cat14=$val14&cat17=$val17&cat18=$val18&cat19=$val19&cat21=$val21&cat22=$val22&cat23=$val23&cat24=$val24&cat25=$val25&cat26=$val26><left>$label98</a><br>" ;









if($cat26==$val26){

//////////////FOR SEO if($cat1==$val1){
$sql = "SELECT  * from allproduct  where refkind='$cat26'  ";  // cat_label
$result = mysql_query( $sql); 

  echo"  SELECT MOUSE SPECT   <BR>"; 
   
			
While( $fetcharr = mysql_fetch_array($result) )
 { 
	    
			
			                                      	$val27= $fetcharr['allproductid'];
									
													$label99 = $fetcharr['refkind'];
													$label111 = $fetcharr['refallband'];
													$label112 = $fetcharr['refallspecial'];
													$label113 = $fetcharr['statusvga'];
													$label114 = $fetcharr['reframselect'];
													$label115 = $fetcharr['vgaslot'];
													$label116 = $fetcharr['alldetail'];
													$label117 = $fetcharr['allprice'];
													$labelpic117 = $fetcharr['allpic'];

						
						

			
				echo "<img src=bullet4.jpg> <a href=comtreeall.php?cat55555=$allbandid&cat1=$val1&cat2=$val2&catcpu=$label4&cat3=$val3&cat4=$val4&cat5=$val5&cat6=$val6&cat7777=$label25&cat7=$val7&cat8=$val8&cat9=$val9&cat11=$val11&cat12=$val12&cat13=$val13&cat14=$val14&cat17=$val17&cat18=$val18&cat19=$val19&cat21=$val21&cat22=$val22&cat23=$val23&cat24=$val24&cat25=$val25&cat26=$val26&cat27=$val27><left>$label116</a><br>" ;




/////////////////////////////////KEY /////////////////////////////////////////////////////


if($cat27==$val27){

//////////////FOR SEO if($cat1==$val1){
$sql = "SELECT *  from kind where kindname='KEYBOARD'  ";  // cat_label
$result = mysql_query( $sql); 
 echo" SELECT KEY BOARD  <BR>"; 
   
			
While( $fetcharr = mysql_fetch_array($result) )
 { 
	    
			
			                                      	$val28= $fetcharr['kindid'];
												
													
													$label118 = $fetcharr['kindname'];
													
							
				echo "<img src=bullet4.jpg> <a href=comtreeall.php?cat55555=$allbandid&cat1=$val1&cat2=$val2&catcpu=$label4&cat3=$val3&cat4=$val4&cat5=$val5&cat6=$val6&cat7777=$label25&cat7=$val7&cat8=$val8&cat9=$val9&cat11=$val11&cat12=$val12&cat13=$val13&cat14=$val14&cat17=$val17&cat18=$val18&cat19=$val19&cat21=$val21&cat22=$val22&cat23=$val23&cat24=$val24&cat25=$val25&cat26=$val26&cat27=$val27&cat28=$val28><left>$label118</a><br>" ;




if($cat28==$val28){

//////////////FOR SEO if($cat1==$val1){
$sql = "SELECT  * from allproduct  where refkind='$cat28'  ";  // cat_label
$result = mysql_query( $sql); 

  echo"  SELECT KEY BOARD SPECT   <BR>"; 
   
			
While( $fetcharr = mysql_fetch_array($result) )
 { 
	    
			
			                                      	$val29= $fetcharr['allproductid'];
									
													$label119 = $fetcharr['refkind'];
													$label121 = $fetcharr['refallband'];
													$label132 = $fetcharr['refallspecial'];
													$label133 = $fetcharr['statusvga'];
													$label134 = $fetcharr['reframselect'];
													$label135 = $fetcharr['vgaslot'];
													$label136 = $fetcharr['alldetail'];
													$label137 = $fetcharr['allprice'];
													$labelpic137 = $fetcharr['allpic'];




			
				echo "<img src=bullet4.jpg> <a href=comtreeall.php?cat55555=$allbandid&cat1=$val1&cat2=$val2&catcpu=$label4&cat3=$val3&cat4=$val4&cat5=$val5&cat6=$val6&cat7777=$label25&cat7=$val7&cat8=$val8&cat9=$val9&cat11=$val11&cat12=$val12&cat13=$val13&cat14=$val14&cat17=$val17&cat18=$val18&cat19=$val19&cat21=$val21&cat22=$val22&cat23=$val23&cat24=$val24&cat25=$val25&cat26=$val26&cat27=$val27&cat28=$val28&cat29=$val29><left>$label136</a><br>" ;


/////////////////////////////////SPEAKER/////////////////////////////////////////////////////




if($cat29==$val29){

//////////////FOR SEO if($cat1==$val1){
$sql = "SELECT *  from kind where kindname='SPEAKER'  ";  // cat_label
$result = mysql_query( $sql); 
 echo" SELECT SPEAKER  <BR>"; 
   
			
While( $fetcharr = mysql_fetch_array($result) )
 { 
	    
			
			                                      	$val31= $fetcharr['kindid'];
												
													
													$label138 = $fetcharr['kindname'];
													
				
				echo "<img src=bullet4.jpg> <a href=comtreeall.php?cat55555=$allbandid&cat1=$val1&cat2=$val2&catcpu=$label4&cat3=$val3&cat4=$val4&cat5=$val5&cat6=$val6&cat7777=$label25&cat7=$val7&cat8=$val8&cat9=$val9&cat11=$val11&cat12=$val12&cat13=$val13&cat14=$val14&cat17=$val17&cat18=$val18&cat19=$val19&cat21=$val21&cat22=$val22&cat23=$val23&cat24=$val24&cat25=$val25&cat26=$val26&cat27=$val27&cat28=$val28&cat29=$val29&cat31=$val31><left>$label138</a><br>" ;


if($cat31==$val31){
//////////////FOR SEO if($cat1==$val1){

$sql = "SELECT  * from allproduct  where refkind='$cat31'  ";  // cat_label
$result = mysql_query( $sql); 

  echo"  SELECT SPEAKER SPECT   <BR>"; 
   
			
While( $fetcharr = mysql_fetch_array($result) )
 { 
	    
			
			                                      	$val32= $fetcharr['allproductid'];
									
													$label139 = $fetcharr['refkind'];
													$label141 = $fetcharr['refallband'];
													$label142 = $fetcharr['refallspecial'];
													$label143 = $fetcharr['statusvga'];
													$label144 = $fetcharr['reframselect'];
													$label145 = $fetcharr['vgaslot'];
													$label146 = $fetcharr['alldetail'];
													$label147 = $fetcharr['allprice'];
													$labelpic147 = $fetcharr['allpic'];

				
					
				echo "<img src=bullet4.jpg> <a href=comtreeall.php?cat55555=$allbandid&cat1=$val1&cat2=$val2&catcpu=$label4&cat3=$val3&cat4=$val4&cat5=$val5&cat6=$val6&cat7777=$label25&cat7=$val7&cat8=$val8&cat9=$val9&cat11=$val11&cat12=$val12&cat13=$val13&cat14=$val14&cat17=$val17&cat18=$val18&cat19=$val19&cat21=$val21&cat22=$val22&cat23=$val23&cat24=$val24&cat25=$val25&cat26=$val26&cat27=$val27&cat28=$val28&cat29=$val29&cat31=$val31&cat32=$val32><left>$label146$label1</a><br>" ;


if($cat32==$val32){
echo "<center><img src=$labelpic77><img src=$labelpic97><img src=$labelpic147><br><p><img src=$labelpic137>";
 echo" <br><p> YOU  COMPUTER  SPECT $labelpic97  <BR>"; 
  echo" <center>            CPU: $label8   <BR>"; 
   echo" <center> MOTHER BOARD: $label27  <BR>"; 
    echo"<center>  MEMORY: $label36   <BR>"; 
	 echo"  <center>: GRAPHIC CARD :$label46    <BR>"; 
	  echo" <center> HARD DIAK: $label56   <BR>"; 
	   echo"<center> CD/DVD: $label66   <BR>"; 
	    echo" <center> FROPY DISK: $label86  <BR>"; 
	   
	    echo"<center>CASE: $label76    <BR>"; 
	   
	    echo"<center>POWER SUPPLY:   <BR>"; 
	   
	    echo"<center>MONITOR: $label96     <BR>"; 
	   
	    echo"<center>MOUSE: $label116     <BR>"; 
	   
	    echo"<center>KEY BOARD:$label136 <BR>"; 
		 echo"<center>SPEAKER:$label146     <BR>"; 
		 echo"CONFIRM YOU COMPUTERSPECT ORDER TO ME!!!!!!! PLEASE CLICK FOR SEND TO ORDER.....    <BR>"; 
	   



}}////////////////2 new

}
}}}}//6
}}}}//5
}}}}//4
}}}}//3
}}}}//2
}}}}//1
//}}}}
}}}}
}}}}
}}}}
}}}}
}}}}
}}}}
}}}}
}}

}/////////////19



?>