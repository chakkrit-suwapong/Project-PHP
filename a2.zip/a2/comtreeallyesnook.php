<font size = '2'
  >
<?php		// menutree.php (Mysql)
require("config.inc.php");



mysql_connect($host, $user, $pw) or  die("�������Ͱҹ�����������");
mysql_query("set NAMES utf8   ");
mysql_select_db($dbname) or die("���͡�ҹ�����������"); // ���͡�ҹ������



$sql = "SELECT *  from kind where kindname='CPU'  ";  // cat_label
$result = mysql_query( $sql); 

	
		echo"  SELECT CPU SPEED FOR $allbandname   <BR>";  
		
			
While( $fetcharr = mysql_fetch_array($result) )
                                                    { 
	    
			
			                                      	$val1= $fetcharr['kindid'];
												
													
													$label1 = $fetcharr['kindname'];
													$labelpic1 = $fetcharr['kindpic'];
													
														
														
														
	                          echo "<img src=bullet4.jpg> <a href=comtreeall.php?cat1=$val1><left>$label1 </a><br>" ;


                                                      


////////////////////////////////////////////////////////////////////////////////////////

if($cat1==$val1)

                                                       {

//////////////FOR SEO if($cat1==$val1){

$sql = "SELECT *  from allband where allbandname='INTEL' or allbandname='AMD' ";  // cat_label
$result = mysql_query( $sql); 

	echo"  SELECT CPU BAND NAME   <BR>";  
While( $fetcharr = mysql_fetch_array($result) )
                                 { 
	    
			
			                                      	$allbandid= $fetcharr['allbandid'];
												
													
													$allbandname = $fetcharr['allbandname'];
													
														
														
														
	                          echo "<img src=bullet4.jpg> <a href=comtreeall.php?cat1=$val1&cat55555=$allbandid><left>$allbandname </a><br>" ;







if($cat55555==$allbandid)
               {







$sql = "SELECT *  from selectnext where selectnextname='YES ' or   selectnextname='NO' ";  // cat_label
$result = mysql_query( $sql); 

	echo"  SELECT CPU BAND NAME   <BR>";  
While( $fetcharr = mysql_fetch_array($result) )
                                  { 
	    
			
			                                      	$valnext= $fetcharr['selectnextid'];
												
													
													$labelnext = $fetcharr['selectnextname'];
													
														
														
														
	                          echo "<img src=bullet4.jpg> <a href=comtreeall.php?cat1=$val1&cat55555=$allbandid&catnext=$labelnext><left>$labelnext </a><br>" ;
                                     }




}

///////////////////////////////////////////////////////////////////////////////////////////////



if($catnext=='YES')
      {



$sql = "SELECT  * from allproduct  where refkind='$cat1'&&refallband='$cat55555'  ";  // cat_label
$result = mysql_query( $sql); 

  echo"  SELECT CPU SPEED   <BR>"; 
   
			
While( $fetcharr = mysql_fetch_array($result) )
                         // { 
	    
			
			                      {                	$val2= $fetcharr['allproductid'];
									
													$label2 = $fetcharr['refkind'];
													$label3 = $fetcharr['refallband'];
													$label4 = $fetcharr['refallspecial'];
													$label5 = $fetcharr['statusvga'];
													$label6 = $fetcharr['reframselect'];
													$label7 = $fetcharr['vgaslot'];
													$label8 = $fetcharr['alldetail'];
													$label9 = $fetcharr['allprice'];
													$labelpic9 = $fetcharr['allpic'];

													
														
														
														
	                          echo "<img src=bullet4.jpg> <a href=comtreeall.php?cat1=$val1&cat55555=$allbandid&catnext=$labelnext&cat1=$val1&cat2=$val2><left>$label8 </a><br>" ;

                                 }



    }					
	
	
	
	if($catnext=='NO')
	
	
      {
	  
	  echo"jakkrit";
	  }
	
	
	
	}

}


}


//////////////////////////////////// MOTHER BOARD SELECT///////////////////////////////////////////









?>