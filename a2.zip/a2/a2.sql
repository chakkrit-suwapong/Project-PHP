-- phpMyAdmin SQL Dump
-- version 2.9.2
-- http://www.phpmyadmin.net
-- 
-- โฮสต์: localhost
-- เวลาในการสร้าง: 04 ม.ค. 2009  น.
-- รุ่นของเซิร์ฟเวอร์: 5.0.27
-- รุ่นของ PHP: 5.2.1
-- 
-- ฐานข้อมูล: `a2`
-- 

-- --------------------------------------------------------

-- 
-- โครงสร้างตาราง `allband`
-- 

CREATE TABLE `allband` (
  `allbandid` int(11) NOT NULL auto_increment,
  `refkind` varchar(25) NOT NULL,
  `allbandname` varchar(25) NOT NULL,
  PRIMARY KEY  (`allbandid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=19 ;

-- 
-- dump ตาราง `allband`
-- 

INSERT INTO `allband` VALUES (1, '1', 'INTEL');
INSERT INTO `allband` VALUES (2, '1', 'AMD');
INSERT INTO `allband` VALUES (3, '2', 'ASUS');
INSERT INTO `allband` VALUES (4, '2', 'ASROCK');
INSERT INTO `allband` VALUES (5, '2', 'DFI');
INSERT INTO `allband` VALUES (6, '2', 'MATSONIC');
INSERT INTO `allband` VALUES (7, '14', 'NVIDIA');
INSERT INTO `allband` VALUES (8, '14', 'G-FORCE');
INSERT INTO `allband` VALUES (9, '14', 'S3 SAVAGE');
INSERT INTO `allband` VALUES (10, '2', 'FUJISU');
INSERT INTO `allband` VALUES (12, '14', 'NVIDIA');
INSERT INTO `allband` VALUES (13, '3', 'KINGTON');
INSERT INTO `allband` VALUES (14, '3', 'LIFEON');
INSERT INTO `allband` VALUES (15, '3', 'LG');
INSERT INTO `allband` VALUES (16, '4', 'SEGATE');
INSERT INTO `allband` VALUES (17, '4', 'MAXTOR');
INSERT INTO `allband` VALUES (18, '4', 'WESTERN');

-- --------------------------------------------------------

-- 
-- โครงสร้างตาราง `allproduct`
-- 

CREATE TABLE `allproduct` (
  `allproductid` int(11) NOT NULL auto_increment,
  `refkind` int(11) NOT NULL,
  `refallband` varchar(25) NOT NULL,
  `refallspecial` varchar(25) NOT NULL,
  `statusvga` varchar(25) NOT NULL,
  `reframselect` varchar(25) NOT NULL,
  `vgaslot` varchar(25) NOT NULL,
  `alldetail` text NOT NULL,
  `allprice` varchar(25) NOT NULL,
  PRIMARY KEY  (`allproductid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=45 ;

-- 
-- dump ตาราง `allproduct`
-- 

INSERT INTO `allproduct` VALUES (7, 4, '7', '10', '', '', '', 'HD SEGATE 7200 RPM  160 G', '3500');
INSERT INTO `allproduct` VALUES (8, 4, '9', '9', '', '', '', 'HD IDE MAXTOR 7200 250 GB', '3800');
INSERT INTO `allproduct` VALUES (9, 7, '6', '', '', '', '', 'DVD RW 16 X', '1800');
INSERT INTO `allproduct` VALUES (10, 6, '8', '', '', '', '', 'CDRW 52 X ', '800');
INSERT INTO `allproduct` VALUES (11, 2, '4', '1', '20', '3', '17', 'ASUS 478 XXXXXX BUS 1300  NO VGA', '2580');
INSERT INTO `allproduct` VALUES (12, 2, '3', '2', '19', '3', '18', 'ASUS 462 XXXX BUS900  VGA ON', '1980');
INSERT INTO `allproduct` VALUES (13, 1, '2', '2', '', '', '', 'ATHLON 3000+', '1500');
INSERT INTO `allproduct` VALUES (14, 1, '1', '1', '', '', '', 'P4 3.0Ghz', '2500');
INSERT INTO `allproduct` VALUES (15, 3, '5', '3', '', '', '', 'DDR1 XXX BUS 333 512 MB', '1200');
INSERT INTO `allproduct` VALUES (16, 3, '2', '3', '', '', '', 'DDR1 BUS 333  1024 MB', '2500');
INSERT INTO `allproduct` VALUES (17, 2, '6', '1', '20', '3', '18', 'MB INTEL 478 BUS 800XXXX NO VGA', '3500');
INSERT INTO `allproduct` VALUES (18, 2, '5', '2', '20', '4', '17', 'ASUS MB 462 XXX NO VGA', '2750');
INSERT INTO `allproduct` VALUES (19, 2, '10', '1', '19', '3', '18', 'ASUS 478 XXXXXX  VGA ON', '3500');
INSERT INTO `allproduct` VALUES (20, 2, '4', '2', '19', '4', '18', 'ASUS 462 xxxxxxxxxxxxxxxxxxx VGA ON', '3800');
INSERT INTO `allproduct` VALUES (21, 14, '13', '18', '', '', '18', 'G-FROCE PCI EXPRESS ', '3500');
INSERT INTO `allproduct` VALUES (22, 14, '12', '17', '', '', '17', 'NVIDIA AGP ', '2500');
INSERT INTO `allproduct` VALUES (23, 1, '2', '2', '', '', '', 'AMD K8 1500 MHZ', '1250');
INSERT INTO `allproduct` VALUES (24, 1, '2', '2', '', '', '', 'AMD K7 2500 MHZ', '2200');
INSERT INTO `allproduct` VALUES (25, 1, '1', '1', '', '', '', 'P4 2.8 GHZ', '1850');
INSERT INTO `allproduct` VALUES (26, 1, '1', '1', '', '', '', 'CELERON 2.2 GHZ', '1250');
INSERT INTO `allproduct` VALUES (27, 3, '5', '6', '', '', '', 'DDR2 XXXXXXXXXXXXX 512MB  BUS 667', '1850');
INSERT INTO `allproduct` VALUES (28, 3, '2', '6', '', '', '', 'DDR2 XXXXXXXXXXXXX  2G  BUS 667', '2500');
INSERT INTO `allproduct` VALUES (29, 3, '5', '7', '', '', '', 'DDR2 XXXXXXXXXXXXX 2028 M BUS 800', '2500');
INSERT INTO `allproduct` VALUES (30, 3, '2', '7', '', '', '', 'DDR2 XXXXXXXXXXXXX 1024 M BUS 800', '2500');
INSERT INTO `allproduct` VALUES (31, 3, '2', '4', '', '', '', 'RAM DDR1  XX BUS 400  1G', '2500');
INSERT INTO `allproduct` VALUES (32, 3, '2', '4', '', '', '', 'RAM DDR1 BUS 400 XXX 2G ', '1250');
INSERT INTO `allproduct` VALUES (33, 2, '3', '1', '20', '7', '18', 'FUJISU MOTHER BOARD 478 NO VGA', '3500');
INSERT INTO `allproduct` VALUES (34, 13, '8', '', '', '', '', 'SUMSUNG SPEAKER 3500 WATT', '');
INSERT INTO `allproduct` VALUES (35, 13, '3', '', '', '', '', 'SUMSUNG2 SPEAKER 3500 WATT', '');
INSERT INTO `allproduct` VALUES (36, 13, '6', '', '', '', '', 'SUMSUNG3 SPEAKER 3500 WATT', '');
INSERT INTO `allproduct` VALUES (37, 13, '6', '', '', '', '', 'SUMSUNG4 SPEAKER 3500 WATT', '');
INSERT INTO `allproduct` VALUES (38, 12, '8', '', '', '', '', 'KEYBOARD 108 KEY ', '');
INSERT INTO `allproduct` VALUES (39, 12, '6', '', '', '', '', 'KEYBOARD 210 KEY ', '');
INSERT INTO `allproduct` VALUES (40, 11, '5', '', '', '', '', 'OPTICAL MOUSE YELLOW ', '');
INSERT INTO `allproduct` VALUES (41, 10, '8', '', '', '', '', 'MONITOR 19 " LCD', '');
INSERT INTO `allproduct` VALUES (42, 9, '6', '', '', '', '', 'POWERSUPPLY  650 WATT', '');
INSERT INTO `allproduct` VALUES (43, 8, '6', '', '', '', '', 'CASE TOWER ALUMINUM ', '');
INSERT INTO `allproduct` VALUES (44, 5, '8', '', '', '', '', 'FROPY DIAK 1.44 MB', '');

-- --------------------------------------------------------

-- 
-- โครงสร้างตาราง `allspecial`
-- 

CREATE TABLE `allspecial` (
  `allspecialid` int(11) NOT NULL auto_increment,
  `refkind` varchar(25) NOT NULL,
  `allspecialname` varchar(25) NOT NULL,
  PRIMARY KEY  (`allspecialid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=23 ;

-- 
-- dump ตาราง `allspecial`
-- 

INSERT INTO `allspecial` VALUES (1, '1', 'SOCKET 478');
INSERT INTO `allspecial` VALUES (2, '1', 'SOCKET 462');
INSERT INTO `allspecial` VALUES (3, '3', 'DDR1 BUS 333');
INSERT INTO `allspecial` VALUES (4, '3', 'DDR1 BUS 400');
INSERT INTO `allspecial` VALUES (5, '3', 'DDR1 BUS 533');
INSERT INTO `allspecial` VALUES (6, '3', 'DDR2 BUS 667');
INSERT INTO `allspecial` VALUES (7, '3', 'DDR2 BUS 800');
INSERT INTO `allspecial` VALUES (8, '3', 'SD RAM BUS 133');
INSERT INTO `allspecial` VALUES (9, '4', 'IDE');
INSERT INTO `allspecial` VALUES (10, '4', 'SATA 1');
INSERT INTO `allspecial` VALUES (17, '2', 'AGP SLOT');
INSERT INTO `allspecial` VALUES (18, '2', 'PCI EXPRESS SLOT');
INSERT INTO `allspecial` VALUES (19, '2', 'VGA ON BOARD ');
INSERT INTO `allspecial` VALUES (20, '2', 'NO VGA ON BOARD ');
INSERT INTO `allspecial` VALUES (22, '2', 'PCI SLOT');

-- --------------------------------------------------------

-- 
-- โครงสร้างตาราง `kind`
-- 

CREATE TABLE `kind` (
  `kindid` int(11) NOT NULL auto_increment,
  `kindname` varchar(25) NOT NULL,
  PRIMARY KEY  (`kindid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=18 ;

-- 
-- dump ตาราง `kind`
-- 

INSERT INTO `kind` VALUES (4, 'HARD DISK');
INSERT INTO `kind` VALUES (5, 'FROPY DISK');
INSERT INTO `kind` VALUES (6, 'CD ');
INSERT INTO `kind` VALUES (7, 'DVD');
INSERT INTO `kind` VALUES (8, 'CASE');
INSERT INTO `kind` VALUES (9, 'POWER SUPPLY');
INSERT INTO `kind` VALUES (10, 'MONITOR');
INSERT INTO `kind` VALUES (11, 'MOUSE');
INSERT INTO `kind` VALUES (12, 'KEYBOARD');
INSERT INTO `kind` VALUES (13, 'SPEAKER');
INSERT INTO `kind` VALUES (14, 'GRAPHIC CARD');
INSERT INTO `kind` VALUES (1, 'CPU');
INSERT INTO `kind` VALUES (2, 'MOTHER BOARD');
INSERT INTO `kind` VALUES (3, 'RAM');

-- --------------------------------------------------------

-- 
-- โครงสร้างตาราง `stepselect`
-- 

CREATE TABLE `stepselect` (
  `stepslectid` int(11) NOT NULL auto_increment,
  `stepselectname` varchar(25) NOT NULL,
  PRIMARY KEY  (`stepslectid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=13 ;

-- 
-- dump ตาราง `stepselect`
-- 

INSERT INTO `stepselect` VALUES (1, 'FRIST STEP');
INSERT INTO `stepselect` VALUES (2, 'SECOND STEP');
INSERT INTO `stepselect` VALUES (3, 'THIRD STEP');
INSERT INTO `stepselect` VALUES (4, 'FOURTH STEP');
INSERT INTO `stepselect` VALUES (5, 'FIFTH STEP');
INSERT INTO `stepselect` VALUES (6, 'SIXTH STEP');
INSERT INTO `stepselect` VALUES (7, 'SEVENTH STEP');
INSERT INTO `stepselect` VALUES (8, 'EIGHTH STEP');
INSERT INTO `stepselect` VALUES (9, 'NINTH STEP');
INSERT INTO `stepselect` VALUES (10, 'TENTH STEP');
INSERT INTO `stepselect` VALUES (11, 'ELEVENTH STEP');
INSERT INTO `stepselect` VALUES (12, 'TWELFTH STEP');
